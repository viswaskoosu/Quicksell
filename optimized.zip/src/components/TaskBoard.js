import React, { useState, useEffect, useMemo } from 'react';
import TaskColumn from './TaskColumn';
import DisplayMenu from './DisplayMenu';
import constants from './constants';
const { API_URL, PRIORITY_MAP, STATUS_ICONS } = constants;

const TaskBoard = () => {
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [groupBy, setGroupBy] = useState(() =>
    localStorage.getItem('groupBy') || 'status'
  );
  const [sortBy, setSortBy] = useState(() =>
    localStorage.getItem('sortBy') || 'priority'
  );

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error('Failed to fetch data');

        const data = await response.json();
        setTasks(data.tickets);
        setUsers(data.users);
        setError(null);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    localStorage.setItem('groupBy', groupBy);
    localStorage.setItem('sortBy', sortBy);
  }, [groupBy, sortBy]);

  const getUserById = (userId) => users.find((user) => user.id === userId);

  const sortTasks = (tasksToSort) => {
    return [...tasksToSort].sort((a, b) => {
      if (sortBy === 'priority') return b.priority - a.priority;
      return a.title.localeCompare(b.title);
    });
  };

  const groupTasks = useMemo(() => {
    const grouped = {};

    if (groupBy === 'status') {
      grouped['Todo'] = [];
      grouped['In progress'] = [];
      grouped['Backlog'] = [];
      grouped['Done'] = [];
      grouped['Cancelled'] = [];
    } else if (groupBy === 'user') {
      users.forEach((user) => {
        grouped[user.name] = [];
      });
    } else if (groupBy === 'priority') {
      Object.values(PRIORITY_MAP).forEach(({ label }) => {
        grouped[label] = [];
      });
    }

    tasks.forEach((task) => {
      if (groupBy === 'status') {
        grouped[task.status].push(task);
      } else if (groupBy === 'user') {
        const user = getUserById(task.userId);
        if (user) {
          grouped[user.name].push(task);
        }
      } else if (groupBy === 'priority') {
        grouped[PRIORITY_MAP[task.priority].label].push(task);
      }
    });

    Object.keys(grouped).forEach((key) => {
      grouped[key] = sortTasks(grouped[key]);
    });

    return grouped;
  }, [tasks, groupBy, sortBy, users]);

  return (
    <div className="task-board">
      {loading && <div>Loading...</div>}
      {error && <div>Error: {error}</div>}
      <div className="task-board-header">
        <DisplayMenu groupBy={groupBy} setGroupBy={setGroupBy} sortBy={sortBy} setSortBy={setSortBy} />
      </div>
      <div className="task-board-body">
        {Object.entries(groupTasks).map(([groupName, tasks]) => (
          <TaskColumn key={groupName} groupName={groupName} tasks={tasks} groupBy={groupBy} />
        ))}
      </div>
      <style jsx>{`
        .task-board {
          padding: 20px;
          background-color: #f4f5f8;
          min-height: 100vh;
        }
        .task-board-header {
          display: flex;
          justify-content: space-between;
        }
        .task-board-body {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 24px;
        }
      `}</style>
    </div>
  );
};

export default TaskBoard;
